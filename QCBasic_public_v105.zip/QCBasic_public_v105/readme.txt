===========================
QCBasic, Version 1.0.5
Made by Rim032, 7/5/21
===========================

--Program Notes--

Thanks for installing my program if you have, I will later add more features. 
This is my first public program, this program isn't meant to have a ton of 
features right now.

You can put the folder of the project anywhere, DO NOT change or modify 
internal files of the program because you might break them. DO NOT DELETE 
ANYTHING, unless if you want to break it. 

**I don't know how to give the program one of those security certificate things**

--QC Output Location--

The QC file will start as "untilted.qc", you will have to rename 
the file to whatever you desire. The QC file will be outputed in 
QCBasic->bin->debug(Also the location of the exe) and sometimes in the QCBasic base folder.

All you have to do is run the exe found within QCBasic->bin->debug.
It is recommended to know stuff about how QC files are setup to
fully utilize this program. Helpful link to learn: https://developer.valvesoftware.com/wiki/QC

--Notes--

Your free to mess with the Source code if your somehow able to obtain it, this
is just a super simple QC maker program for the Source Engine that can be utilized
by modellers. Please do not republish source code publicly, you can modify it.

I planned on making this look good visually using the GTK 3 library for C but
I haven't got the library to work with Codeblocks properly, so I am just using
the default console app GUI, sorry :(.

--Contact Info--

You may contact me on Steam if you have any bugs, issues or questions. PLEASE
leave a comment if your trying to contact me on steam about QCBasic because
I do not accept random friend request's without a comment first, sorry.
===============================================================================

--|Build Versions|--

1.0.0 - 7/3/21 - Alpha Version #1 - Distributed to a few people for testing.
1.0.1 - 7/3/21 - Beta Version #1 - More features, cleaner and easier to use.
1.0.2 - 7/3/21 - Beta Version #2 - Bug fixes, polishing.
1.0.3 - 7/4/21 - Beta Version #3 - Visual improvements, general improvements.
1.0.4 - 7/4/21 - Beta Version #4 - More features, bug fixes.
1.0.5 - 7/5/21 - Beta Version #4 - Small bug fixes.